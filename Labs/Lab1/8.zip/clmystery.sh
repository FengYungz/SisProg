
cat entrevista-904020
cat entrevista-9620713
cat entrevista-29741223
cd entrevistas
head -n 224 Travessa_Andover
head -n 284 Travessa_Dunstable
head -n 275 Rua_Plainfield
head -n 7 Rua_Plainfield
cd ruas
grep Maher pessoas
grep Emryus pessoas
grep Germuska pessoas
grep Erika pessoas
grep L337* automoveis -A 6
cat entrevista-699607
cat entrevista-47246024
cd entrevistas/
head -n 179 Vila_Buckingham
head -n 40 Vila_Hart
cd ruas
grep Annabel pessoas
head -n 20 pessoas
cd misterio
cat dica1
grep PISTA cena-do-crime
cd misterio/
grep loira Vila_Hart
grep blonde Vila_Hart
cat Vila_Hart
grep blonde Vila_Buckingham
grep loira Vila_Buckingham
cat Vila_Buckingham
grep Vila Buckingham ruas
cat pessoas
grep PISTA cedna-do-crime.txt
grep PISTA cedna-do-crime,txt
grep PISTA cedna-do-crime
cat cena-do-crime
cat inicio
echo Emryus Arnane
